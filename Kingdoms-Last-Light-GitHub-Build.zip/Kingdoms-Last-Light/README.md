# Kingdom's Last Light — Android starter

This is a small Android WebView RPG starter project.

## Build
Open this project in Android Studio, or use the included GitHub Actions workflow in the repository after extracting this ZIP.

The current game is a basic prototype with Explore, Fight, Rest, Shop, HP, Gold, and Royal Gems display.

## Important
- This is not a finished production RPG.
- Gold and Royal Gems are local demo values only.
- Google Play Billing, server-side purchase verification, cloud saves, and production security are not implemented.
- The generated debug APK is for testing, not Play Store release.
