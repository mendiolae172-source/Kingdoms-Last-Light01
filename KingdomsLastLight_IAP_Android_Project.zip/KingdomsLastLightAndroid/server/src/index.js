import express from "express";
import helmet from "helmet";
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { google } from "googleapis";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "16kb" }));

const PORT = Number(process.env.PORT || 8080);
const PACKAGE_NAME = process.env.PLAY_PACKAGE_NAME || "com.kingdomslastlight.game";
initializeApp({ credential: applicationDefault() });
const db = getFirestore();
const auth = new google.auth.GoogleAuth({
  scopes: ["https://www.googleapis.com/auth/androidpublisher"]
});
const play = google.androidpublisher({ version: "v3", auth });

/**
 * Product IDs must exactly match the one-time products created in Play Console.
 * Gem bundles are consumable. Equipment/cosmetics are permanent entitlements.
 * Never accept gem amounts or item IDs supplied by the client as authoritative.
 */
const CATALOG = Object.freeze({
  gems_100:   { kind: "gems", amount: 100, consumable: true },
  gems_550:   { kind: "gems", amount: 550, consumable: true },
  gems_1200:  { kind: "gems", amount: 1200, consumable: true },
  gems_3500:  { kind: "gems", amount: 3500, consumable: true },
  gems_8000:  { kind: "gems", amount: 8000, consumable: true },
  royal_armor:        { kind: "item", item: "royal_armor", consumable: false },
  dragon_companion:   { kind: "item", item: "dragon_companion", consumable: false },
  knight_skin:        { kind: "item", item: "knight_skin", consumable: false }
});

async function requireFirebaseUser(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) return res.status(401).json({ error: "Sign-in required" });
    const decoded = await getAuth().verifyIdToken(header.slice(7), true);
    req.uid = decoded.uid;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired sign-in token" });
  }
}
app.use("/v1", requireFirebaseUser);

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/v1/wallet", async (req, res) => {
  const ref = db.collection("players").doc(req.uid);
  const snap = await ref.get();
  const data = snap.exists ? snap.data() : {};
  res.json({
    gold: Number(data.gold || 0),
    royalGems: Number(data.royalGems || 0),
    inventory: data.inventory || []
  });
});

app.post("/v1/purchases/verify", async (req, res) => {
  const { purchaseToken, productId } = req.body || {};
  if (typeof purchaseToken !== "string" || purchaseToken.length < 20 ||
      typeof productId !== "string" || !CATALOG[productId]) {
    return res.status(400).json({ error: "Invalid purchase details" });
  }

  const item = CATALOG[productId];
  try {
    // Ask Google Play directly. Never trust client-side "purchase successful" callbacks.
    const { data: purchase } = await play.purchases.products.get({
      packageName: PACKAGE_NAME,
      productId,
      token: purchaseToken
    });

    // purchaseState 0 = PURCHASED. Pending/canceled purchases receive no entitlement.
    if (purchase.purchaseState !== 0) {
      return res.status(409).json({ error: "Purchase is not in PURCHASED state" });
    }

    const tokenRef = db.collection("playPurchaseTokens").doc(purchaseToken);
    const playerRef = db.collection("players").doc(req.uid);
    const outcome = await db.runTransaction(async tx => {
      const prior = await tx.get(tokenRef);
      if (prior.exists) {
        const saved = prior.data();
        if (saved.uid !== req.uid || saved.productId !== productId) {
          throw new Error("PURCHASE_TOKEN_ALREADY_USED");
        }
        return {
          alreadyProcessed: true,
          needsStoreAction: saved.storeActionCompleted !== true
        };
      }

      const playerSnap = await tx.get(playerRef);
      const player = playerSnap.exists ? playerSnap.data() : {};
      const updates = {
        gold: Number(player.gold || 0),
        royalGems: Number(player.royalGems || 0),
        inventory: Array.isArray(player.inventory) ? player.inventory : [],
        updatedAt: FieldValue.serverTimestamp()
      };

      if (item.kind === "gems") updates.royalGems += item.amount;
      else if (!updates.inventory.includes(item.item)) updates.inventory.push(item.item);

      tx.set(playerRef, updates, { merge: true });
      tx.create(tokenRef, {
        uid: req.uid, productId, consumable: item.consumable,
        processedAt: FieldValue.serverTimestamp()
      });
      return { alreadyProcessed: false };
    });

    // Consume gem bundles so they can be purchased again. Acknowledge permanent items.
    // If this call fails, token idempotency prevents a second grant; retry can finish it.
    if (outcome.needsStoreAction) {
      if (item.consumable) {
        await play.purchases.products.consume({ packageName: PACKAGE_NAME, productId, token: purchaseToken });
      } else if (purchase.acknowledgementState !== 1) {
        await play.purchases.products.acknowledge({
          packageName: PACKAGE_NAME, productId, token: purchaseToken,
          requestBody: {}
        });
      }
      await tokenRef.set({ storeActionCompleted: true }, { merge: true });
    }

    const walletSnap = await playerRef.get();
    const wallet = walletSnap.data() || {};
    return res.json({
      ok: true,
      alreadyProcessed: outcome.alreadyProcessed,
      message: outcome.alreadyProcessed ? "Purchase already delivered." : "Purchase verified and delivered.",
      gold: Number(wallet.gold || 0),
      royalGems: Number(wallet.royalGems || 0),
      inventory: wallet.inventory || []
    });
  } catch (error) {
    if (error.message === "PURCHASE_TOKEN_ALREADY_USED") {
      return res.status(409).json({ error: "This purchase token was already used by another account" });
    }
    console.error("Purchase verification failed", error?.message || error);
    return res.status(500).json({ error: "Purchase verification could not be completed. Please retry." });
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => console.log(`Billing API listening on ${PORT}`));
