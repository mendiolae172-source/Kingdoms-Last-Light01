package com.kingdomslastlight.game

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.*

class MainActivity : Activity() {
    private lateinit var gameView: WebView
    private lateinit var billing: BillingManager
    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @Suppress("DEPRECATION")
    private fun immersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    private fun configureFirebaseIfProvided() {
        if (FirebaseApp.getApps(this).isNotEmpty()) return
        if (BuildConfig.FIREBASE_APP_ID.isBlank() || BuildConfig.FIREBASE_API_KEY.isBlank() ||
            BuildConfig.FIREBASE_PROJECT_ID.isBlank()) return
        val options = FirebaseOptions.Builder()
            .setApplicationId(BuildConfig.FIREBASE_APP_ID)
            .setApiKey(BuildConfig.FIREBASE_API_KEY)
            .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
            .build()
        FirebaseApp.initializeApp(this, options)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        immersiveMode()
        configureFirebaseIfProvided()

        billing = BillingManager(
            activity = this,
            backendUrl = BuildConfig.BILLING_BACKEND_URL,
            idTokenProvider = {
                val auth = try { FirebaseAuth.getInstance() } catch (_: Exception) { null }
                if (auth == null) null
                else {
                    val user = auth.currentUser ?: auth.signInAnonymously().await().user
                    user?.getIdToken(false)?.await()?.token
                }
            },
            onMessage = { message ->
                runOnUiThread { gameView.evaluateJavascript("window.onBillingMessage(${org.json.JSONObject.quote(message)});", null) }
            },
            onWallet = { walletJson ->
                runOnUiThread { gameView.evaluateJavascript("window.onWalletUpdated($walletJson);", null) }
            }
        )

        gameView = WebView(this)
        gameView.setBackgroundColor(android.graphics.Color.rgb(16, 26, 43))
        gameView.webViewClient = WebViewClient()
        gameView.webChromeClient = WebChromeClient()
        gameView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
        }
        gameView.addJavascriptInterface(GameBillingBridge(), "AndroidBilling")
        setContentView(gameView)
        gameView.loadUrl("file:///android_asset/index.html")
        billing.connect()
    }

    inner class GameBillingBridge {
        @JavascriptInterface fun purchase(productId: String) {
            runOnUiThread { billing.launchPurchase(productId) }
        }
        @JavascriptInterface fun loadProducts() {
            runOnUiThread { billing.queryProducts() }
        }
        @JavascriptInterface fun refreshWallet() {
            runOnUiThread { billing.fetchWallet() }
        }
    }

    fun sendProductsToGame(json: String) {
        if (::gameView.isInitialized) gameView.evaluateJavascript("window.onProductsLoaded($json);", null)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersiveMode()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        Toast.makeText(this, "Use the in-game controls to continue your adventure.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::billing.isInitialized) billing.close()
        activityScope.cancel()
        if (::gameView.isInitialized) gameView.destroy()
        super.onDestroy()
    }
}
