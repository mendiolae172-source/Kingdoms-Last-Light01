package com.kingdomslastlight.game

import android.app.Activity
import com.android.billingclient.api.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Google Play Billing client.
 * Purchases are NOT credited locally: the purchase token is sent to the trusted backend,
 * which verifies it with Google Play and updates the server-side wallet.
 */
class BillingManager(
    private val activity: Activity,
    private val backendUrl: String,
    private val idTokenProvider: suspend () -> String?,
    private val onMessage: (String) -> Unit,
    private val onWallet: (String) -> Unit
) : PurchasesUpdatedListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val productIds = listOf(
        "gems_100", "gems_550", "gems_1200", "gems_3500", "gems_8000",
        "royal_armor", "dragon_companion", "knight_skin"
    )
    private val details = mutableMapOf<String, ProductDetails>()

    private val client = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
        )
        .build()

    fun connect(onReady: (() -> Unit)? = null) {
        if (client.isReady) { onReady?.invoke(); return }
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    onReady?.invoke()
                } else onMessage("Google Play Billing is unavailable: ${result.debugMessage}")
            }
            override fun onBillingServiceDisconnected() {
                onMessage("Connection to Google Play was interrupted. Please try again.")
            }
        })
    }

    fun queryProducts() {
        if (!client.isReady) { connect { queryProducts() }; return }
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            productIds.map { id ->
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build()
            }
        ).build()
        client.queryProductDetailsAsync(params) { result, response ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onMessage("Couldn't load the shop: ${result.debugMessage}")
                return@queryProductDetailsAsync
            }
            details.clear()
            response.productDetailsList.forEach { details[it.productId] = it }
            val arr = org.json.JSONArray()
            response.productDetailsList.forEach { product ->
                val offer = product.oneTimePurchaseOfferDetailsList?.firstOrNull()
                arr.put(JSONObject().apply {
                    put("id", product.productId)
                    put("title", product.title)
                    put("description", product.description)
                    put("price", offer?.formattedPrice ?: "Unavailable")
                })
            }
            activity.runOnUiThread {
                (activity as? MainActivity)?.sendProductsToGame(arr.toString())
            }
        }
    }

    fun launchPurchase(productId: String) {
        if (!client.isReady) { connect { launchPurchase(productId) }; return }
        val product = details[productId]
        if (product == null) {
            onMessage("That item is not available yet. Please try again later.")
            queryProducts()
            return
        }
        val params = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(product)
            .build()
        val flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(params))
            .build()
        val result = client.launchBillingFlow(activity, flow)
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
            onMessage("Purchase could not start: ${result.debugMessage}")
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases.orEmpty().forEach { purchase ->
                if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                    submitForVerification(purchase)
                } else if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
                    onMessage("Payment is pending. Your items will arrive after Google confirms payment.")
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> onMessage("Purchase canceled.")
            else -> onMessage("Purchase error: ${result.debugMessage}")
        }
    }

    private fun submitForVerification(purchase: Purchase) {
        scope.launch {
            try {
                val idToken = withContext(Dispatchers.IO) { idTokenProvider() }
                if (idToken.isNullOrBlank()) {
                    onMessage("Sign-in is not configured. Your purchase has not been credited yet; reopen the game after setup.")
                    return@launch
                }
                val token = purchase.purchaseToken
                val productId = purchase.products.firstOrNull()
                    ?: throw IllegalStateException("Missing product ID")
                val body = JSONObject().put("purchaseToken", token).put("productId", productId)
                val response = withContext(Dispatchers.IO) {
                    postJson("$backendUrl/v1/purchases/verify", body.toString(), idToken)
                }
                onMessage(response.optString("message", "Purchase verified."))
                fetchWallet()
            } catch (e: Exception) {
                onMessage("Purchase received but verification is still pending. Please reopen the game when online.")
            }
        }
    }

    fun fetchWallet() {
        scope.launch {
            try {
                val idToken = withContext(Dispatchers.IO) { idTokenProvider() } ?: return@launch
                val result = withContext(Dispatchers.IO) {
                    getJson("$backendUrl/v1/wallet", idToken)
                }
                onWallet(result.toString())
            } catch (_: Exception) {
                onMessage("Couldn't refresh your online wallet.")
            }
        }
    }

    private fun postJson(url: String, body: String, bearer: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $bearer")
        }
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (connection.responseCode !in 200..299) throw IllegalStateException(text)
        return JSONObject(text)
    }

    private fun getJson(url: String, bearer: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("Authorization", "Bearer $bearer")
        }
        val text = connection.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(text)
    }

    fun close() {
        scope.cancel()
        if (client.isReady) client.endConnection()
    }
}
