plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kingdomslastlight.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.kingdomslastlight.game"
        minSdk = 23
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0"

        // Fill these from your own Firebase project before building a release.
        buildConfigField("String", "FIREBASE_APP_ID", "\\"\\"")
        buildConfigField("String", "FIREBASE_API_KEY", "\\"\\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\\"\\"")
        buildConfigField("String", "BILLING_BACKEND_URL", "\\"https://YOUR_BACKEND_HOST\\"")
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.android.billingclient:billing:9.1.0")
    implementation(platform("com.google.firebase:firebase-bom:34.5.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
}
