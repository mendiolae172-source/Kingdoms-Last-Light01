# Kingdom's Last Light — Android RPG + Google Play Billing starter

## Included
- Android WebView game shell (the current prototype is 2.5D/pseudo-3D canvas, not a full 3D engine).
- Google Play Billing Library 9.1.0 client integration.
- Shop UI for Royal Gem bundles and permanent armor/pet/skin unlocks.
- Firebase Authentication ID-token handoff (configuration required).
- Node.js backend using Firebase Admin + Google Play Developer API.
- Server-side purchase-token verification and idempotent wallet grants in Firestore.
- Consumable gem bundles are consumed server-side; permanent unlocks are acknowledged server-side.

## Important: not production-ready until configured and tested
This package is source code. It is NOT a compiled APK/AAB, not published to Google Play, and cannot process real payments until you create/configure your own Google/Firebase projects and Play Console products. No private keys or credentials are included.

## Product IDs to create in Play Console
Create these as one-time in-app products with matching IDs:
- Consumable: `gems_100`, `gems_550`, `gems_1200`, `gems_3500`, `gems_8000`
- Non-consumable: `royal_armor`, `dragon_companion`, `knight_skin`

Set actual prices and availability in Play Console. The current shop supports currency, armor, a companion pet and cosmetic skins. The app reads localized price strings from Google Play. The example PHP/peso prices previously discussed are not hard-coded as final prices.

## Required configuration
1. Create a Firebase project and enable **Anonymous Authentication** (or replace it with your preferred authenticated account system).
2. Add the Firebase Android app with package `com.kingdomslastlight.game`.
3. Copy the Firebase app ID, Web API key, and project ID into the three `FIREBASE_*` buildConfig fields in `app/build.gradle.kts`.
4. Replace `BILLING_BACKEND_URL` with your HTTPS backend URL.
5. Deploy the backend in `server/`:
   - Use Node.js 20+.
   - `cd server && npm install`
   - Set `PLAY_PACKAGE_NAME=com.kingdomslastlight.game`.
   - Configure Firebase Admin Application Default Credentials for the same Firebase project.
   - Grant the backend service account the minimum required Google Play Developer API access to verify, consume and acknowledge in-app purchases for this app.
   - Enable the Google Play Android Publisher API.
   - Deploy behind HTTPS. Do not expose service-account keys in the app.
6. Create the Firestore database. The backend creates `players` and `playPurchaseTokens` documents as needed.
7. Configure the app's Firebase Authentication provider to issue ID tokens; the client currently expects a signed-in Firebase user. For a quick controlled test, sign in anonymously in the app before opening the marketplace. Do not rely on client-provided player IDs.
8. Build and test using Play Console internal testing and license tester accounts.

## Security model
- The app never grants paid currency based on a local callback.
- The app sends the Google Play purchase token plus product ID and Firebase ID token to the backend.
- The backend verifies the purchase directly with Google Play and only grants when `purchaseState == PURCHASED`.
- Firestore records purchase tokens to prevent duplicate grants and cross-account token reuse.
- Pending purchases receive no currency or item.
- Gem bundles are consumable; permanent unlocks are acknowledged.
- Never ship Firebase Admin credentials, Google service-account keys, signing keys, or backend secrets inside the Android app.

## Current limitations / production work still required
- Add an account sign-in/anonymous sign-in screen and recovery/account linking before release. Firebase credentials above must be configured.
- Add purchase restore/queryPurchases flow before production. The backend records whether Google Play consume/acknowledge completed so a retried verification can finish that step without granting currency twice.
- Add refund/chargeback handling (Voided Purchases API) and Real-time Developer Notifications (RTDN) to revoke/refund entitlements as appropriate.
- Add server-side purchase retry queue if consume/acknowledge calls fail after the entitlement transaction.
- Add proper server-authoritative gameplay economy: Gold rewards, gem spending, and inventory purchases should be performed by authenticated backend endpoints, not trusted from WebView local state.
- Add privacy policy, data safety disclosures, content rating, testing, support contact, store listing, and policy review.
- Have a parent/guardian manage developer registration, payments, legal details, and publishing if the developer is under 18.

## Build
Open the project folder in Android Studio with Android SDK 36 installed. Sync Gradle, configure Firebase/backend values, test on a real device through Play internal testing, then generate a signed Android App Bundle (AAB). Keep the signing key secure.
